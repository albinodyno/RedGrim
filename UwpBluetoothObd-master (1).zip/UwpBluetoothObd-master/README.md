# UwpBluetoothObd
This is a small illustration for connecting to an ELM 327 Bluetooth enabled OBD-II adapter from a Raspberry Pi 3.
